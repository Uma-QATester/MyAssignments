package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.SFbaseClass;
/*-LoginPage 1.url main login page 
-WelcomePage 2.register mobile page
-MyHomePage 3.SF Home Page -App Launcher - View All- Sales
-MyAccountPage  4.click Account - click New
-CreateAccountPage 5. New Account creation 
-ViewAccountPage 6.View Account*/

public class SFLoginPage extends SFbaseClass {
	
	public SFLoginPage(ChromeDriver driver) {
		this.driver=driver;
		}
	

	public SFLoginPage enterusername() {
	driver.findElement(By.id("username")).sendKeys("uma.job969584@agentforce.com");
	return this;
	}

	
	public SFLoginPage enterpassword(){
		driver.findElement(By.id("password")).sendKeys("Twinkle9E6");
		return this;
	}

	public SFWelcomepage clickLogin() {
		driver.findElement(By.xpath("//input[@name='Login']")).click();
		 SFWelcomepage wp=new SFWelcomepage(driver);
	     return wp;
}
}
