package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.SFbaseClass;
/*/*-LoginPage 1.url main login page 
-WelcomePage 2.register mobile page
-MyHomePage 3.SF Home Page -App Launcher - View All- Sales
-MyAccountPage  4.click Account - click New
-CreateAccountPage 5. New Account creation 
-ViewAccountPage 6.View Account - verify account */
public class SFHomePage extends SFbaseClass{
	
	public SFHomePage(ChromeDriver driver) {
		this.driver=driver;
		}
	

	public SFHomePage clickToggleMenuButton() throws InterruptedException {
		driver.findElement(By.xpath("//button[@title='App Launcher']")).click();
		Thread.sleep(5000);
		return this;

	}

	
	public SFHomePage clickviewall() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		Thread.sleep(5000);
		return this;
		
	}

	
	public SFAccountsPage applauncher() throws InterruptedException {
		driver.findElement(By.xpath("//div[@data-name='Sales']//p[@style='display: inline']")).click();
		Thread.sleep(5000);
		return new SFAccountsPage(driver);

	}
}
