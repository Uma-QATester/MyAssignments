package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import base.SFbaseClass;
/*-LoginPage 1.url main login page 
-WelcomePage 2.register mobile page
-MyHomePage 3.SF Home Page -App Launcher - View All- Sales
-MyAccountPage  4.click Account - click New
-CreateAccountPage 5. New Account creation 
-ViewAccountPage 6.View Account*/
public class SFAccountsPage extends SFbaseClass{
	
	public SFAccountsPage(ChromeDriver driver) {
		this.driver=driver;
		}
	
	public SFAccountsPage clickAccount() throws InterruptedException {
		WebElement account = driver.findElement(By.xpath("//a[@title='Accounts']"));
		driver.executeScript("arguments[0].click();", account);
		Thread.sleep(2000);
		return this;
	}	
		
	public SFCreateAccountsPage clickNewButton() throws InterruptedException {
			driver.findElement(By.xpath("//a[@title='New']//div[@title='New']")).click();
			Thread.sleep(2000);
			return new SFCreateAccountsPage(driver);
		}
		

	}


