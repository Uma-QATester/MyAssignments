package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.SFbaseClass;

public class SFViewAccountPage extends SFbaseClass{
	
	public SFViewAccountPage(ChromeDriver driver) {
		this.driver=driver;
		}
	
	//System.out.println("New Sales Force Account is Created");
	String name= "Uma";
	public void verifyAccountName() throws InterruptedException {
		/*
		 * WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		 * WebElement accountName1 =
		 * wait.until(ExpectedConditions.visibilityOfElementLocated
		 * (By.xpath("//a[contains(@class, 'slds-truncate')]//span[contains(text(), '" +
		 * name + "')]")));
		 * 
		 * Thread.sleep(2000); String displayedName = accountName1.getText().trim();
		 * 
		 * if (displayedName.equalsIgnoreCase(name)) {
		 * System.out.println("Account Name is displayed correctly as :" +
		 * displayedName); } else { System.out.println(
		 * "Account Name is not displayed correctly as :" + displayedName +
		 * " but expected name is: " + name);
		 * 
		 * }
		 */
		String verifymsg = driver.findElement(By.xpath("(//a[@class='forceActionLink']/div)[3]"))
				.getText();

		if (verifymsg.contains("Uma")) {
			System.out.println("New Account Created");
		} else {
			System.out.println("Account not Created");
		}

	}

}
