package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.SFbaseClass;

/*/*-LoginPage 1.url main login page 
-WelcomePage 2.register mobile page
-MyHomePage 3.SF Home Page -App Launcher - View All- Sales
-MyAccountPage  4.click Account - click New
-CreateAccountPage 5. New Account creation 
-ViewAccountPage 6.View Account*/
public class SFWelcomepage extends SFbaseClass{
	
	public SFWelcomepage(ChromeDriver driver) {
		this.driver=driver;
		}
	
	public SFHomePage registerPhone() {
	WebDriverWait phoneRemind = new WebDriverWait(driver, Duration.ofSeconds(5));
	try {
		WebElement remindMeLatterButton = phoneRemind
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Remind Me Later']")));
		remindMeLatterButton.click();
		System.out.println("Clicked on Remind Me Later.");

	} catch (Exception e) {
		System.out.println("No Remind Me Later pop-up this time.");
	}
	return new SFHomePage(driver);

}
}
