package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import base.SFbaseClass;
import io.cucumber.java.en.When;
/*/*-LoginPage 1.url main login page 
-WelcomePage 2.register mobile page
-MyHomePage 3.SF Home Page -App Launcher - View All- Sales
-MyAccountPage  4.click Account - click New
-CreateAccountPage 5. New Account creation 
-ViewAccountPage 6.View Account*/
public class SFCreateAccountsPage extends SFbaseClass {
	
	public SFCreateAccountsPage(ChromeDriver driver) {
		this.driver=driver;
		}
	String accountName= "Uma";
	public SFCreateAccountsPage enterName(String accountName) {
		driver.findElement(By.xpath("//input[@name='Name']")).sendKeys(accountName);
		
		System.out.println("Entered Account Name: " + accountName);
		return this;
	}

	@When("Select Ownership as Public")
	public SFCreateAccountsPage selectPublicOwnership() {
		WebElement ownership = driver.findElement(By.xpath("(//button[@aria-label='Ownership'])"));
		driver.executeScript("arguments[0].click();", ownership);

		WebElement publicOwnership = driver.findElement(By.xpath("//span[text()='Public']"));
		driver.executeScript("arguments[0].click();", publicOwnership);
		
		return this;
	}

	@When("Click Save")
	public SFViewAccountPage clickSave() throws InterruptedException {
		driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();
		Thread.sleep(2000);
		return new SFViewAccountPage(driver);

	}
	

}
