package base;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

//import pages.LoginPage;

/*/*-LoginPage 1.url main login page 
-WelcomePage 2.register mobile page
-MyHomePage 3.SF Home Page -App Launcher - View All- Sales
-MyAccountPage  4.click Account - click New
-CreateAccountPage 5. New Account creation 
-ViewAccountPage 6.View Account
*/
public class SFbaseClass {
	public  ChromeDriver driver;
	public  ChromeOptions options; 

	@BeforeMethod
	public void preConditions() {
		options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		options.addArguments("--user-data-dir=C:\\Users\\MasTER\\Selenium1");
		driver = new ChromeDriver(options);

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		driver.get("https://login.salesforce.com");
		driver.manage().window().maximize();

	}

	@AfterMethod
	public void postConditions() {
		driver.quit();

	}
}
