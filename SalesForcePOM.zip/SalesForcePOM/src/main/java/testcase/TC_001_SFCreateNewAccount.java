package testcase;

import org.testng.annotations.Test;

import base.SFbaseClass;
import pages.SFLoginPage;

public class TC_001_SFCreateNewAccount extends SFbaseClass{
	@Test
	public void createNewAccount() throws InterruptedException {
		/*/*-LoginPage 1.url main login page 
		-WelcomePage 2.register mobile page
		-MyHomePage 3.SF Home Page -App Launcher - View All- Sales
		-MyAccountPage  4.click Account - click New
		-CreateAccountPage 5. New Account creation 
		-ViewAccountPage 6.View Account */
		 		 //LoginPage
				SFLoginPage lp=new SFLoginPage(driver);
				lp.enterusername()
				.enterpassword()
				.clickLogin()//link Welcome Page
				//Welcome Page
				.registerPhone()//link My Home Page
				//My Home Page
				.clickToggleMenuButton()
				.clickviewall()
				.applauncher()//link Accounts Page
				//Accounts Page
				.clickAccount()
				.clickNewButton()//link CreateNew Account Page
				//Create New Account Page
				.enterName("Uma")
				.selectPublicOwnership()
				.clickSave()//link View Account Page
				//View Account Page
				.verifyAccountName();
	}
	

}
