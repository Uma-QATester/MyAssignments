package salesforceAutomation;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

public class ProjectBaseClass {
	// Open Browser
	// Disable Notification
	public static ChromeDriver driver;
	public  ChromeOptions options; 

	@Parameters({ "url", "uname", "pword" })
	@BeforeMethod
	public void preConditions(String url, String userName, String password) throws InterruptedException {
		options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		options.addArguments("--user-data-dir=C:\\Users\\MasTER\\Selenium1");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		// Get Url
		driver.get("https://login.salesforce.com");

		// Enter Username & Password
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys(userName);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(password);
		// Click Login
		driver.findElement(By.xpath("//input[@id='Login']")).click();
		Thread.sleep(3000);
		WebDriverWait phoneRemind = new WebDriverWait(driver, Duration.ofSeconds(5));
		try {
			WebElement remindMeLatterButton = phoneRemind
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Remind Me Later']")));
			remindMeLatterButton.click();
			System.out.println("Clicked on Remind Me Later.");

		} catch (Exception e) {
			System.out.println("No Remind Me Later pop-up this time.");
		}

	}

	
	  @AfterMethod 
	  public void postconditions() {
		  driver.quit(); 
		  }
	 

}