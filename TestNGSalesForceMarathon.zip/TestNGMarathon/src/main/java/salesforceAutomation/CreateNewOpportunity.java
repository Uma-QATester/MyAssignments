package salesforceAutomation;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;



public class CreateNewOpportunity extends ProjectBaseClass {

	@DataProvider(name = "fetchData")
	public String[][] sendData() throws IOException {
		String[][] read = ReadXLMarathonData.readOppData();
		return read;
	}

	@Test(dataProvider="fetchData")
	public void runCreateOpp(String opName, String opAmount) throws InterruptedException {
// Click on toggle menu button
		driver.findElement(By.xpath("//button[@title='App Launcher']")).click();
		Thread.sleep(2000);

//  Click view All
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		Thread.sleep(2000);
		
//  Click Sales from App Launcher		
		driver.findElement(By.xpath("//div[@data-name='Sales']//p[@style='display: inline']")).click();
		Thread.sleep(2000);
		
// Click on Opportunity tab 		
		WebElement opportunity = driver.findElement(By.xpath("//a[@title='Opportunities']"));
		driver.executeScript("arguments[0].click();", opportunity);
		Thread.sleep(2000);
		
// Click on New button
		driver.findElement(By.xpath("//a[@title='New']//div[@title='New']")).click();
		Thread.sleep(2000);

// Enter Opportunity name & Store it
		WebElement oppName = driver.findElement(By.xpath("//label[text()='Opportunity Name']/following::input[1]"));
		oppName.sendKeys(opName);
		
		WebElement amountOpp = driver.findElement(By.xpath("//input[@name='Amount']"));
		amountOpp.sendKeys(opAmount);

// Choose close date as Today
		WebElement date= driver.findElement(By.xpath("//label[text()='Close Date']/following::input[1]"));
		driver.executeScript("arguments[0].click();", date);
		Thread.sleep(2000);
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement today = wait.until(ExpectedConditions.elementToBeClickable(
			    By.xpath("//table[@class='slds-datepicker__month']//tr[3]/td[3]")));
		today.click();
		
		 
// Select 'Stage' as Need Analysis
		
		  WebElement stage=driver.findElement(By.xpath("//span[text()='--None--']"));
		  driver.executeScript("arguments[0].click();", stage); 
		  Thread.sleep(2000);
		 

		WebElement selectAnalysis = driver .findElement(By.xpath("//span[text()='--None--']/following::span[text()='Needs Analysis']"));
		driver.executeScript("arguments[0].click();", selectAnalysis);
		Thread.sleep(2000);
// click Save
		WebElement saveCheck= driver.findElement(By.xpath("//button[@name='SaveEdit']"));
		driver.executeScript("arguments[0].click();", saveCheck);
		Thread.sleep(2000);
		
// VerifyOppurtunity Name		
		
		String verifymsg = driver.findElement(By.xpath("(//a[@class='forceActionLink']/div)[3]"))
				.getText();

		if (verifymsg.contains("Uma")) {
			System.out.println("New Opportunity Created");
		} else {
			System.out.println("Opportunity not Created");
		}
		}
	}

