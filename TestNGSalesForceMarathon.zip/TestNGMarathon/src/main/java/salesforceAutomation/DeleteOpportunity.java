package salesforceAutomation;

import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DeleteOpportunity extends ProjectBaseClass {

	// "1. Login to https://login.salesforce.com
	// 2. Click on toggle menu button from the left corner
	// 3. Click view All and click Sales from App Launcher
	// 4. Click on Opportunity tab
	// 5. Search the Opportunity 'Salesforce Automation by *Your Name*'
	// 6. Click on the Dropdown icon and Select Delete
	// 7. Verify Whether Oppurtunity is Deleted using Oppurtunity Name

	@Test
	public void runDeleteOpp()throws InterruptedException {

		// Click on toggle menu button
				driver.findElement(By.xpath("//button[@title='App Launcher']")).click();
				Thread.sleep(2000);

		//  Click view All
				driver.findElement(By.xpath("//button[text()='View All']")).click();
				Thread.sleep(2000);
				
		//  Click Sales from App Launcher		
				WebElement sales = driver.findElement(By.xpath("//div[@data-name='Sales']//p[@style='display: inline']"));
				driver.executeScript("arguments[0].click();", sales);
				Thread.sleep(2000);
				
		// Click on Opportunity tab 		
				WebElement account = driver.findElement(By.xpath("//a[@title='Opportunities']"));
				driver.executeScript("arguments[0].click();", account);
				Thread.sleep(2000);

//		driver.findElement(By.xpath("//div[contains(@class,'test-listviewdisplayswitcher')]")).click();
//		driver.findElement(By.xpath("//li[@title='Kanban']")).click();

		// 5. Search the Opportunity 'Salesforce Automation by *Your Name*'
		WebElement oppName = driver.findElement(By.xpath("//label[text()='Search this list...']//following::input[1]"));
		oppName.sendKeys("Uma");
		Thread.sleep(2000);
		oppName.sendKeys(Keys.ENTER);

		// 6. Click on the Dropdown icon and Select Delete
		if(driver.findElements(By.xpath("//button[@type='button']//span[text()='Show Actions']")).isEmpty()){
		    System.out.println("No opportunities found to delete!");
		    return; // exit test
		}
		else {
		Thread.sleep(3000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement showAction = wait.until(ExpectedConditions.elementToBeClickable(
		        By.xpath("//button[@type='button']//span[text()='Show Actions']")));
		driver.executeScript("arguments[0].click();", showAction);

		WebElement elementDelete = driver.findElement(
				By.xpath("//div[@role='menu']//a[@title='Delete']"));
		driver.executeScript("arguments[0].click();", elementDelete);
		
		WebElement confirmDelete = driver.findElement(By.xpath("//span[text()='Delete']"));
		driver.executeScript("arguments[0].click();", confirmDelete);
		
		driver.navigate().refresh();
		Thread.sleep(3000);
		
		// Verify whether the Opportunity is deleted using the Opportunity Name.
		String checkName = "Uma";
		WebElement verifymsg = driver.findElement(By.xpath("//label[text()='Search this list...']/following::input[1]"));
		verifymsg.clear();
		verifymsg.sendKeys(checkName);
		verifymsg.sendKeys(Keys.ENTER);
		Thread.sleep(3000);
				
		List<WebElement> opps = driver.findElements(By.xpath("//a[@title='" + checkName + "']"));
		
		if (opps.isEmpty()) {
			System.out.println("Opportunity not deleted as list is empty");
		} else {
			System.out.println("Opportunity deleted");
		}
		}
	}
}
