package salesforceAutomation;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class EditOpprtunity extends ProjectBaseClass{
	

	/*
	 * @DataProvider(name = "fetchData") public String[] sendData() throws
	 * IOException { String[] read = ReadEditData.readEditData(); return read; }
	 * 
	 * @Test(dataProvider="fetchData")
	 */
	@Test
	public void runEditOpp() throws InterruptedException {
// Click on toggle menu button
				driver.findElement(By.xpath("//button[@title='App Launcher']")).click();
				Thread.sleep(2000);

//  Click view All
				driver.findElement(By.xpath("//button[text()='View All']")).click();
				Thread.sleep(2000);
				
//  Click Sales from App Launcher		
				WebElement sales = driver.findElement(By.xpath("//div[@data-name='Sales']//p[@style='display: inline']"));
				driver.executeScript("arguments[0].click();", sales);
				Thread.sleep(2000);
				
// Click on Opportunity tab 		
				WebElement opportunity = driver.findElement(By.xpath("//a[@title='Opportunities']"));
				driver.executeScript("arguments[0].click();", opportunity);
				Thread.sleep(2000);

//		driver.findElement(By.xpath("//div[contains(@class,'test-listviewdisplayswitcher')]")).click();
//		driver.findElement(By.xpath("//li[@title='Kanban']")).click();

// Search the Opportunity 'Salesforce Automation by *Your Name*'
		WebElement oppName = driver.findElement(By.xpath("//label[text()='Search this list...']//following::input[1]"));
		oppName.sendKeys("Uma");
		Thread.sleep(2000);
		oppName.sendKeys(Keys.ENTER);

		// ,Keys.ENTER);

// Click on the Dropdown icon and Select Edit
		Thread.sleep(3000);
		//driver.findElement(By.xpath("//a[@title='Show 4 more actions']")).click();
		
		if(driver.findElements(By.xpath("//button[@type='button']//span[text()='Show Actions']")).isEmpty()){
		    System.out.println("No opportunities found to edit!");
		    return; // exit test
		}
		else {

		WebElement showAction = driver.findElement(By.xpath("//button[@type='button']//span[text()='Show Actions']"));
		driver.executeScript("arguments[0].click();", showAction);
		
		//span[@data-cell-type='lstListViewRowLevelAction']//span[text()='Show Actions']
		Thread.sleep(3000);
		WebElement elementEdit = driver.findElement(
				By.xpath("//div[@role='menu']//a[@title='Edit']"));
		driver.executeScript("arguments[0].click();", elementEdit);
//Choose the close date as Tomorrow's date.
		driver.findElement(By.xpath("//input[@name='CloseDate']")).click();
		WebElement date = driver.findElement(By.xpath("//table[@class='slds-datepicker__month']//tr[4]/td[2]"));
		driver.executeScript("arguments[0].click();", date);

		Thread.sleep(3000);
//Select Stage to Perception Analysis
		WebElement analysis =driver.findElement(By.xpath("(//span[text()='--None--'])[3]"));
		driver.executeScript("arguments[0].click();", analysis);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement analysisOption = wait.until(ExpectedConditions.elementToBeClickable(
		        By.xpath("//span[text()='Perception Analysis']")));
		driver.executeScript("arguments[0].click();", analysisOption);


		Thread.sleep(3000);
//Select Delivery/Installation Status to In-progress
		WebElement analysis1 =driver.findElement(By.xpath("(//span[text()='--None--'])[4]"));
		driver.executeScript("arguments[0].click();", analysis1);

		WebElement progress = driver.findElement(By.xpath("//span[text()='In progress']"));
		driver.executeScript("arguments[0].click();", progress);


		Thread.sleep(3000);
		driver.executeScript("document.body.style.zoom='80%'", "");
//Enter Description as 'SalesForce'.		
		driver.findElement(By.xpath("//textarea[@class='slds-textarea']")).sendKeys("Salesforce");

//Click on 'Save' and verify the Stage as 'Perception Analysis'.
		
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(30));
		WebElement saveButton = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@name='SaveEdit']")));
		saveButton.click();

		WebElement verify = driver.findElement(By.xpath("(//span[text()='Perception Analysis'])"));

		System.out.println("The Opportunity is edited with stage as " + verify.getText());

	}
	}
}
