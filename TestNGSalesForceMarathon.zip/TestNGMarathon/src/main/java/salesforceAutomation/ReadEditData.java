package salesforceAutomation;

import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadEditData {
	public static String[] readEditData() throws IOException{
		XSSFWorkbook wb=new XSSFWorkbook("./Data/EditOpportunityExcel.xlsx");
		
		XSSFSheet ws = wb.getSheetAt(0);
		DataFormatter formatter = new DataFormatter();
				int rowCount = ws.getLastRowNum();
				System.out.println("The row count is: "+rowCount);
				
				int physicalNumberOfRows = ws.getPhysicalNumberOfRows();
				System.out.println("The row "+physicalNumberOfRows);
				
				
				
				String[] data=new String[rowCount];
				
				for(int i=1;i<=rowCount;i++) {
					
					XSSFRow row = ws.getRow(i);
					if (row != null && row.getCell(0) != null) {
				        data[i - 1] = formatter.formatCellValue(row.getCell(0));
					} else {
					    data[i-1] = "";
					}
					
				    System.out.println("Row " + i + ": " + data[i - 1]);
				}
					
				wb.close();
				return data;
	}
	
	}
