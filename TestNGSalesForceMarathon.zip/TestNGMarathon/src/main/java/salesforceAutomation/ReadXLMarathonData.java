package salesforceAutomation;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadXLMarathonData {

	public static String[][] readOppData() throws IOException {
		XSSFWorkbook wb = new XSSFWorkbook("./Data/ReadExcelMarathon.xlsx");

		XSSFSheet ws = wb.getSheetAt(0);
		
		int lastRowCount = ws.getLastRowNum();//returns index of last row

		int lastColumnCount = ws.getRow(0).getLastCellNum();//returns the number of column in first row as row(0)
		System.out.println("The last row count is: " + lastRowCount);
		System.out.println("The last column count is: " + lastColumnCount);
		
		
		  int physicalNumberOfRows = ws.getPhysicalNumberOfRows();
		  System.out.println("The actual row count - " + physicalNumberOfRows);
		 


		String row1Cell1Data = ws.getRow(1).getCell(1).getStringCellValue();
		System.out.println("The data in row1-column1 is: " + row1Cell1Data);

		String[][] data = new String[physicalNumberOfRows-1][lastColumnCount];//skip header

		for (int i = 1; i < physicalNumberOfRows; i++) {//start at row 1 so to skip header

			XSSFRow row = ws.getRow(i);

			for (int j = 0; j < lastColumnCount; j++) {
				if (row != null && row.getCell(j) != null) {
					String allData = row.getCell(j).getStringCellValue();

					data[i - 1][j] = allData;

					System.out.print(allData + " ");
				}

			}
		}
		wb.close();
		return data;
	}
}