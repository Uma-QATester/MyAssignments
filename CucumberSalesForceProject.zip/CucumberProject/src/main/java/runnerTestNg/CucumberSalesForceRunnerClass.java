package runnerTestNg;
//Home Assignment <4>: Pass Data from ScenarioOutline&Examples Cucumber Dynamic Parameterization - 08/10/2025
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/main/java/features/SalesForce.feature",glue = "stepsDefinition", tags="@EditAccount")
public class CucumberSalesForceRunnerClass extends AbstractTestNGCucumberTests{

}
