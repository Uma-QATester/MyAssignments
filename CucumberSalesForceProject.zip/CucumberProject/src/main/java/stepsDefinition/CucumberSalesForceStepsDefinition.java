package stepsDefinition;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CucumberSalesForceStepsDefinition extends BaseSalesForceClass {
	public String name="Uma";
	@Given("Launch the SalesForce browser")
	public void launch_the_browser() {
		driver = new ChromeDriver();
	}

	@Given("Load the SalesForce URL")
	public void load_the_url() {
		driver.get("https://login.salesforce.com");
		driver.manage().window().maximize();
	}

	@Given("Enter the username as uma.job969584@agentforce.com")
	public void enter_the_username_as_uma_job969584_agentforce_com() {
		driver.findElement(By.id("username")).sendKeys("uma.job969584@agentforce.com");
	}

	@Given("Enter the password as Twinkle9E6")
	public void enter_the_password_as_twinkle9e6() {
		driver.findElement(By.id("password")).sendKeys("Twinkle9E6");
	}

	@When("Click on the SalesForce Login button")
	public void click_on_the_login_button() {
		driver.findElement(By.xpath("//input[@name='Login']")).click();
		WebDriverWait phoneRemind = new WebDriverWait(driver, Duration.ofSeconds(5));
		try {
			WebElement remindMeLatterButton = phoneRemind
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Remind Me Later']")));
			remindMeLatterButton.click();
			System.out.println("Clicked on Remind Me Later.");

		} catch (Exception e) {
			System.out.println("No Remind Me Later pop-up this time.");
		}
		// driver.findElement(By.xpath("//a[text()='Remind Me Later']")).click();

	}

	@When("Click on the toggle menu button")
	public void click_on_the_toggle_menu_button() throws InterruptedException {
		driver.findElement(By.xpath("//button[@title='App Launcher']")).click();
		Thread.sleep(5000);

	}

	@When("Click View All")
	public void click_view_all() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		Thread.sleep(5000);
	}

	@When("Select Sales from App Launcher")
	public void select_sales_from_app_launcher() throws InterruptedException {
		driver.findElement(By.xpath("//div[@data-name='Sales']//p[@style='display: inline']")).click();
		Thread.sleep(5000);

	}

	@When("Click on the Accounts tab")
	public void click_on_the_accounts_tab() throws InterruptedException {
		WebElement account = driver.findElement(By.xpath("//a[@title='Accounts']"));
		driver.executeScript("arguments[0].click();", account);
		Thread.sleep(2000);

	}

	@When("Click on the New button")
	public void click_on_the_new_button() throws InterruptedException {
		driver.findElement(By.xpath("//a[@title='New']//div[@title='New']")).click();
		Thread.sleep(2000);
	}

	@When("Enter your name as (.*)$")
	public void enter_your_name_as_Uma_Meenakshisundaram(String accountName) {
		driver.findElement(By.xpath("//input[@name='Name']")).sendKeys(accountName);
		name = accountName;
		System.out.println("Entered Account Name: " + accountName);
	}

	@When("Select Ownership as Public")
	public void select_ownership_as_public() {
		WebElement ownership = driver.findElement(By.xpath("(//button[@aria-label='Ownership'])"));
		driver.executeScript("arguments[0].click();", ownership);

		WebElement publicOwnership = driver.findElement(By.xpath("//span[text()='Public']"));
		driver.executeScript("arguments[0].click();", publicOwnership);
	}

	@When("Click Save")
	public void click_save() throws InterruptedException {
		driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();
		Thread.sleep(2000);

	}

//ERROR
	@Then("Verify the new Account Name is correctly displayed")
	public void verify_the_new_account_name_is_correctly_displayed() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement accountName = wait.until(ExpectedConditions.visibilityOfElementLocated
				(By.xpath("//a[contains(@class, 'slds-truncate')]//span[contains(text(), '" + name + "')]")));

		Thread.sleep(2000);
		 String displayedName = accountName.getText().trim();

		if (displayedName.equalsIgnoreCase(name)) {
			System.out.println("Account Name is displayed correctly as :" + displayedName);
		} else {
			System.out.println(
					"Account Name is not displayed correctly as :" + displayedName + " but expected name is: " + name);

		}

	}

//Edit Account
	@When("Click on the Accounts tab")
	public void click_on_the_accounts_tab1() throws InterruptedException {
		WebElement account = driver.findElement(By.xpath("//a[@title='Accounts']"));
		driver.executeScript("arguments[0].click();", account);
		Thread.sleep(2000);

	}

	@Given("Search for the account using your unique account name {string}")
	public void search_for_the_account_using_your_unique_account_name(String string) throws InterruptedException {
		WebElement searchName = driver.findElement(By.xpath("//input[@class='slds-input']"));
		searchName.sendKeys(name);
		Thread.sleep(2000);
		searchName.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
	}

	@When("Click the dropdown icon next to the account and select Edit")
	public void click_the_dropdown_icon_next_to_the_account_and_select_edit() throws InterruptedException {
		WebElement showAction = driver
				.findElement(By.xpath("((//lightning-button-menu[contains(@class,'slds-dropdown-trigger')])[7])"
						+ "//span[text()='Show Actions']))"));
		driver.executeScript("arguments[0].click();", showAction);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@role='menuitem']//div[@title='Edit']")).click();
		Thread.sleep(2000);

	}

	@Given("Set Type to Technology Partner")
	public void set_type_to_technology_partner() throws InterruptedException {
		WebElement typeLabel = driver.findElement(By.xpath("//button[@aria-label='Type']"));
		driver.executeScript("arguments[0].click();", typeLabel);
		Thread.sleep(2000);
		WebElement techPartner = driver
				.findElement(By.xpath("//lightning-base-combobox-item[@data-value='Technology Partner']"));
		driver.executeScript("arguments[0].click();", techPartner);
		Thread.sleep(2000);

	}

	@Given("Set Industry to Healthcare")
	public void set_industry_to_healthcare() throws InterruptedException {
		WebElement industry = driver.findElement(By.xpath("//button[@aria-label='Industry']"));
		driver.executeScript("arguments[0].click();", industry);
		Thread.sleep(2000);
		WebElement healthCare = driver
				.findElement(By.xpath("//lightning-base-combobox-item[@data-value='Healthcare']"));
		driver.executeScript("arguments[0].click();", healthCare);
		Thread.sleep(2000);

	}

	@Given("Enter the Billing Address {string}")
	public void enter_the_billing_address(String billingAddressValue) {
		WebElement billingAddress = driver.findElement(By.xpath("//input[@aria-label='Billing Country']"));
		billingAddress.sendKeys(billingAddressValue);

	}

	@Given("Enter the Ship Address {string}")
	public void enter_the_ship_address(String shipAddressValue) {
		WebElement shipAddress = driver.findElement(By.xpath("//input[@aria-label='Shipping Country']"));
		shipAddress.sendKeys(shipAddressValue);
	}

	@Given("Set Customer Priority to Low")
	public void set_customer_priority_to_low() {
		// Write code here that turns the phrase above into concrete actions
		throw new io.cucumber.java.PendingException();
	}

	@Given("Set SLA to Silver")
	public void set_sla_to_silver() {
		// Write code here that turns the phrase above into concrete actions
		throw new io.cucumber.java.PendingException();
	}

	@Given("Set Active to NO")
	public void set_active_to_no() {
		// Write code here that turns the phrase above into concrete actions
		throw new io.cucumber.java.PendingException();
	}

	@Given("Enter a unique number in the Phone field {string}")
	public void enter_a_unique_number_in_the_phone_field(String string) {
		// Write code here that turns the phrase above into concrete actions
		throw new io.cucumber.java.PendingException();
	}

	@Given("Set Upsell Opportunity to No")
	public void set_upsell_opportunity_to_no() {
		// Write code here that turns the phrase above into concrete actions
		throw new io.cucumber.java.PendingException();
	}

	@Then("Verify the phone number is {string}")
	public void verify_the_phone_number_is(String string) {
		// Write code here that turns the phrase above into concrete actions
		throw new io.cucumber.java.PendingException();
	}
}