package stepsDefinition;

import org.openqa.selenium.chrome.ChromeDriver;

public class BaseSalesForceClass {
	public ChromeDriver driver;
	public String name; 
	
	
	
}

