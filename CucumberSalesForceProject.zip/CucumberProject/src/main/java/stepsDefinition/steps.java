package stepsDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class steps {
	public ChromeDriver driver;
	
	@Given("Launch the browser")
	public void launch_the_browser() {
	    driver= new ChromeDriver();
	}

	@Given("Load the URL")
	public void load_the_url() {
		driver.get("http://leaftaps.com/opentaps/control/main");
	}

	@Given("Enter the username as {string}")
	public void enter_the_username_as(String userName) {
		driver.findElement(By.id("username")).sendKeys(userName);

	}

	@Given("Enter the password as {string}")
	public void enter_the_password_as(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}


	@When("Click on the Login button")
	public void click_on_the_login_button() {
		driver.findElement(By.className("decorativeSubmit")).click();

	}

	@Then("Login to the next page")
	public void login_to_the_next_page() {
	   System.out.println("Expected Login condition passed");
	}

	@But("Error on Login")
	public void error_on_login() {
		   System.out.println("Login Failed");

	}

}
